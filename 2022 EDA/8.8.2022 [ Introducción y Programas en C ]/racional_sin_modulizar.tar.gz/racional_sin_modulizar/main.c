// Estructuras de Datos y Algoritmos - Curso 2022
// Tecnologo en Informatica FIng - DGETP - UTEC
//
// main.c
// Racional sin Modulizar.

#include <iostream>

using namespace std;

struct racional{
	int num;
	int den;
};

racional suma(racional r1, racional r2){
	racional ret;
	ret.num = r1.num*r2.den + r2.num*r1.den;
	ret.den = r1.den * r2.den;
	return ret;
}

racional mult(racional r1, racional r2){
	racional ret;
	ret.num = r1.num * r2.num;
	ret.den = r1.den * r2.den;
	return ret;
}

racional div(racional r1, racional r2){
	racional ret;
	ret.num = r1.den * r2.num;
	ret.den = r1.num * r2.den;
	return ret;
}

void imprimir(racional r){
	cout << r.num << "/" << r.den;
}




int main(){
	racional r1, r2, sum, mul, divi;
	r1.num = 1;
	r1.den = 2;

	r2.num = 1;
	r2.den = 2;
	
	sum = suma(r1,r2);
	mul = mult(r1,r2);
	divi = div(r1,r2);

	
	imprimir(r1);	
	cout << " + ";
	imprimir(r2);
	cout << " = ";
	imprimir(sum);
	cout << "\n";
	
	imprimir(r1);	
	cout << " * ";
	imprimir(r2);
	cout << " = ";
	imprimir(mul);
	cout << "\n";
	
	imprimir(r1);	
	cout << " / ";
	imprimir(r2);
	cout << " = ";
	imprimir(divi);
	cout << "\n";

	

	return 1;
}

