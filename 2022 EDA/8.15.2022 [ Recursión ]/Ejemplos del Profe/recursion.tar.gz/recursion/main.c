// Estructuras de Datos y Algoritmos - Curso 2022
// Tecnologo en Informatica FIng - DGETP - UTEC
//
// main.c
// Ejemplos Recursion, etc.

#include <iostream>
#include <string.h>
#include <stdio.h>
#include <unistd.h>

using namespace std;

unsigned int factorial (unsigned int n){
// Retorna el factorial de n.
	if (n == 0)
		return 1;
	else
		return n * factorial(n -1);
}

unsigned int suma(unsigned int a, unsigned int b){
// Retorna la suma de a y b implementado de manera recursiva.
	sleep(1);
	if (b == 0){
		cout << "PB\n";
		return a;
	}else{
		cout << "PI\n";
		return suma (a +1, b -1);
	}
}

unsigned int multiplicacion (unsigned int a, unsigned int b){
// Retorna el producto de a y b de manera recursiva.
	if ((a == 0) || (b == 0))
		return 0;
	else if (a == 1)
		return b;
	else if (b == 1)
		return a;
	else
		return a + multiplicacion(a, b -1);
}

int main(int argc, char * argv[]){

	if (strcmp (argv[1], "fact") == 0){
		cout << atoi(argv[2]) << "! = ";
		cout << factorial(atoi(argv[2])) << endl;	

	}else if (strcmp (argv[1], "mult") == 0){
		cout << atoi(argv[2]) << " x " << atoi(argv[3]) << " = ";
		cout << multiplicacion(atoi(argv[2]), atoi(argv[3])) << endl;	
	}else if (strcmp (argv[1], "suma") == 0){
		unsigned int num = suma(atoi(argv[2]), atoi(argv[3]));
		cout << atoi(argv[2]) << " + " << atoi(argv[3]) << " = ";
		cout << num << endl;
	}else{
		cout << "ERROR: operacion debe ser suma, mult, fact\n";
	}

/*
	for (int i = 0; i< argc; i++){
		cout << "argv[" << i << "] = " << argv[i] << endl;
	
	}
*/	
	
	return 1;
}

