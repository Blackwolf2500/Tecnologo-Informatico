// Estructuras de Datos y Algoritmos - Curso 2022
// Tecnologo en Informatica FIng - DGETP - UTEC
//
// main.c
// Ejemplos punteros, etc.

#include <iostream>


using namespace std;


int main(){
	
	
	int arr[10];
	
	for (int i=0; i<10; i++){
		arr[i] = i;
	}
	
	for (int i=0; i<10000; i++){
		cout << "arr[" << i << "] = " << arr[i] << endl;
	}
	


	int *a;
	a = new(int);
	*a = 3;
	int *b;
	b = new(int);
	*b = 7;
	cout << a << "->" << *a << endl;
	cout << b << "->" << *b << endl << endl;
	a = b;
	
	cout << a << "->" << *a << endl;
	cout << b << "->" << *b << endl << endl;
	
	delete a;
	delete b;


	return 1;
}

