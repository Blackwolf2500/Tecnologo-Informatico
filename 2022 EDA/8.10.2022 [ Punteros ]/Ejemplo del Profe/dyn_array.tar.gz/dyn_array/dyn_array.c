// Estructuras de Datos y Algoritmos - Curso 2022
// Tecnologo en Informatica FIng - DGETP - UTEC
//
// dyn_array.c
// Modulo Implementación Arreglo Dinámico.

#include "dyn_array.h"
#include <string.h>

struct nodo_dynar{
	char * cadena;
	int tam;
};

dynar dynar_crear(int tam){
// Crea un Arreglo dinamico de tamaño tam.
	dynar aux = new(nodo_dynar);
	aux->tam = tam;
	aux->cadena = new char[tam];
	return aux;
}

dynar dynar_ins(dynar d, char * cadena){
// Setea la cadena en d.
// Pre: largo cadena <= tamaño d
	strcpy(d->cadena, cadena);
	return d;
}


int dynar_tam(dynar d){
// Retorna el tamaño de d.
	return d->tam;
}

char * dynar_cad(dynar d){
// Retorna la cadena en d.
	return d->cadena;
}

dynar dynar_redimension(dynar d, int tam){
// Redimensiona d tam lugares.
// Post: al redimensionar con numeros negativos se trunca la cadena tam lugares.

	char * aux = new char[d->tam + tam];
	
	if (d->tam + tam < d->tam){
		for (int i=0; i < d->tam + tam; i++)
			aux[i] = d->cadena[i];
	}else{
		for (int i=0; i<d->tam; i++)
			aux[i] = d->cadena[i];
	}
	d->tam += tam; // d->tam = d->tam + tam;
	delete [] d->cadena;
	d->cadena = aux;
	return d;
}



dynar dynar_destruir(dynar d){
// Destruye d y libera la memoria asociada.
	delete [] d->cadena;
	delete d;
	return d;
}

